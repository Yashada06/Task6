
create table orders (
order_id varchar(50) primary key,
OrderDate date,
customer_id varchar(50),
region varchar(50), 
product_id varchar(50),
sale float,
profit float,
discount float, 
quantity int, 
category varchar(50));

create table product (
product_id varchar(50) primary key,
product_name varchar(50),
category varchar(50),
sub_category varchar(50));

create table customer 
(
customer_id varchar(50) primary key,
customer_name varchar(50),
segment varchar(50)
);

copy orders FROM 'D:\Yashada Docs\Internship Tasks\Task6\order.csv' DELIMITER ',' CSV HEADER;

SET datestyle = 'ISO, DMY';
copy orders FROM 'D:\Yashada Docs\Internship Tasks\Task6\order.csv' DELIMITER ',' CSV HEADER;

select * from orders;

--Total sales by category
select sum(sale) as total_sales, category
from orders
group by category;

--Count the number of orders for each customer
select count(order_id), customer_id
from orders
group by customer_id;

--sales by region with rank
select region, sum(sale)as total_sales, rank() over (order by sum(sale)desc) as sale_rank
from orders
group by region;

--Analyze customer profitability by segment
select 
customer.customer_id, 
customer.segment, 
sum(profit) as total_profit
from 
customer
join 
orders on customer.customer_id= orders.customer_id
group by 
customer.customer_id, 
customer.segment
order by 
total_profit desc
limit 5;

-- 5. Rank Products by Sales within Each Category
select 
orders.category,
product_name,
sum(sale) as total_sales,
rank() over( partition by orders.category order by sum(sale) desc) as sale_rank

from 
orders
join 
product on orders.product_id = product.product_id

group by orders.category, product_name
order by 
orders.category , sale_rank;

-- 6. Total Sales per Customer by Product Category (sale>500)

select 
customer.customer_id,
customer.customer_name,
orders.category,
sum(sale) as total_sales
from orders
join
 customer on orders.customer_id = customer.customer_id
 join 
 product on orders.product_id = product.product_id
 where 
 orderdate between '2024-01-01' and '2024-12-31'
 group by 
 customer.customer_id,
customer.customer_name,
orders.category
 having 
 sum(sale)>500
 order by total_sales desc
 limit 5;

 --Monthly Revenue and Order Analysis
 SELECT 
    TO_CHAR(orderdate,'month') AS month,
    COUNT(*) AS order_count,
    SUM(sale) AS total_revenue,
    AVG(sale) AS average_order_value
FROM orders
WHERE orderdate BETWEEN '15-1-2024' AND '9-2-2024'  
GROUP BY TO_CHAR(orderdate,'month')
ORDER BY month;

--find name of customers from their ID
SELECT customer_name 
FROM customer 
WHERE customer_id IN ('CUST001', 'CUST003');

SELECT COUNT(DISTINCT order_id) AS order_volume
FROM orders;