
create table orders (
order_id varchar(50) primary key,
OrderDate date,
customer_id varchar(50),
region varchar(50), 
product_id varchar(50),
sale float,
profit float,
discount float, 
quantity int, 
category varchar(50));

create table product (
product_id varchar(50) primary key,
product_name varchar(50),
category varchar(50),
sub_category varchar(50));

create table customer 
(
customer_id varchar(50) primary key,
customer_name varchar(50),
segment varchar(50)
);

copy orders FROM 'D:\Yashada Docs\Internship Tasks\Task6\order.csv' DELIMITER ',' CSV HEADER;

SET datestyle = 'ISO, DMY';
copy orders FROM 'D:\Yashada Docs\Internship Tasks\Task6\order.csv' DELIMITER ',' CSV HEADER;

select * from orders;
